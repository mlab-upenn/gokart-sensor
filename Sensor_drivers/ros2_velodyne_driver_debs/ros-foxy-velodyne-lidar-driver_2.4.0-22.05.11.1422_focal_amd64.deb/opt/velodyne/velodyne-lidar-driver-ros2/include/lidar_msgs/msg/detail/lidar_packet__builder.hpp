// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from lidar_msgs:msg/LidarPacket.idl
// generated code does not contain a copyright notice

#ifndef LIDAR_MSGS__MSG__DETAIL__LIDAR_PACKET__BUILDER_HPP_
#define LIDAR_MSGS__MSG__DETAIL__LIDAR_PACKET__BUILDER_HPP_

#include "lidar_msgs/msg/detail/lidar_packet__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace lidar_msgs
{

namespace msg
{

namespace builder
{

class Init_LidarPacket_data
{
public:
  explicit Init_LidarPacket_data(::lidar_msgs::msg::LidarPacket & msg)
  : msg_(msg)
  {}
  ::lidar_msgs::msg::LidarPacket data(::lidar_msgs::msg::LidarPacket::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::lidar_msgs::msg::LidarPacket msg_;
};

class Init_LidarPacket_header
{
public:
  Init_LidarPacket_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LidarPacket_data header(::lidar_msgs::msg::LidarPacket::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_LidarPacket_data(msg_);
  }

private:
  ::lidar_msgs::msg::LidarPacket msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::lidar_msgs::msg::LidarPacket>()
{
  return lidar_msgs::msg::builder::Init_LidarPacket_header();
}

}  // namespace lidar_msgs

#endif  // LIDAR_MSGS__MSG__DETAIL__LIDAR_PACKET__BUILDER_HPP_
