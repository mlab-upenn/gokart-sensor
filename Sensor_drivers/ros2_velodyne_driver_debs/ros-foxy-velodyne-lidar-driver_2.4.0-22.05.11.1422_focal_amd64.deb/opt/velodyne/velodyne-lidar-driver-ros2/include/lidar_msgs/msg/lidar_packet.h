// generated from rosidl_generator_c/resource/idl.h.em
// with input from lidar_msgs:msg/LidarPacket.idl
// generated code does not contain a copyright notice

#ifndef LIDAR_MSGS__MSG__LIDAR_PACKET_H_
#define LIDAR_MSGS__MSG__LIDAR_PACKET_H_

#include "lidar_msgs/msg/detail/lidar_packet__struct.h"
#include "lidar_msgs/msg/detail/lidar_packet__functions.h"
#include "lidar_msgs/msg/detail/lidar_packet__type_support.h"

#endif  // LIDAR_MSGS__MSG__LIDAR_PACKET_H_
